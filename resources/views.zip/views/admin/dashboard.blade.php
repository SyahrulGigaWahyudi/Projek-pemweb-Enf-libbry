@extends('layouts.admin')

@section('content')
    <div class="container mx-auto px-6 py-10">
        <h2 class="text-3xl font-semibold text-blue-700 mb-2">Selamat datang di Dashboard Admin</h2>
        <p class="text-lg text-gray-600">Mari mulai atur isi website kamu seperti buku, rekomendasi, dan lainnya.</p>
    </div>
@endsection
